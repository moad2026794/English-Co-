package com.coach.english

import android.content.Context
import java.time.LocalDate

class Store(c: Context) {
    private val p = c.getSharedPreferences("coach", 0)
    private val today get() = LocalDate.now().toString()
    private val yesterday get() = LocalDate.now().minusDays(1).toString()
    private val last get() = p.getString("last", "") ?: ""

    val streak: Int get() = if (last == today || last == yesterday) p.getInt("streak", 0) else 0
    val lessonIndex: Int get() = p.getInt("day", 0) - (if (last == today) 1 else 0)

    fun done(): Set<Int> = (p.getStringSet("d_$today", emptySet()) ?: emptySet()).map { it.toInt() }.toSet()

    fun complete(i: Int) {
        val n = done() + i
        p.edit().putStringSet("d_$today", n.map { it.toString() }.toSet()).apply()
        if (n.size == 6 && last != today) {
            val st = if (last == yesterday) p.getInt("streak", 0) + 1 else 1
            p.edit().putInt("streak", st).putString("last", today).putInt("day", p.getInt("day", 0) + 1).apply()
        }
    }
}
