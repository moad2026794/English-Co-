package com.coach.english

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var onSpeech: (String) -> Unit = {}
    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { onSpeech(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale.US }
        val store = Store(this)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme { Surface(Modifier.fillMaxSize()) { App(store, ::speak, ::listen) } }
            }
        }
    }

    private fun speak(t: String) { tts?.setSpeechRate(0.85f); tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u") }

    private fun listen(cb: (String) -> Unit) {
        onSpeech = cb
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        try { launcher.launch(i) } catch (e: Exception) { }
    }

    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

data class Blk(val name: String, val min: Int, val icon: String)
val blocks = listOf(
    Blk("مراجعة سريعة", 5, "🔁"), Blk("مفردات جديدة", 10, "📚"), Blk("استماع", 10, "🎧"),
    Blk("قواعد", 10, "🧩"), Blk("محادثة ونطق", 15, "🎤"), Blk("كتابة", 10, "✍️")
)

@Composable
fun App(s: Store, speak: (String) -> Unit, listen: ((String) -> Unit) -> Unit) {
    var screen by remember { mutableStateOf(-1) }
    var done by remember { mutableStateOf(s.done()) }
    val n = lessons.size
    val idx = ((s.lessonIndex % n) + n) % n
    val lesson = lessons[idx]
    val prev = lessons[(idx + n - 1) % n]

    if (screen < 0) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("مرحباً! أنا معلمك 👋", style = MaterialTheme.typography.headlineMedium)
            Text("🔥 أيام متتالية: ${s.streak}")
            Text("درس اليوم: ${lesson.title}", style = MaterialTheme.typography.titleLarge)
            LinearProgressIndicator(progress = { done.size / 6f }, Modifier.fillMaxWidth())
            Text("أنجزت ${done.sumOf { blocks[it].min }} من 60 دقيقة")
            blocks.forEachIndexed { i, b ->
                Card(Modifier.fillMaxWidth().clickable { screen = i }) {
                    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(b.icon, style = MaterialTheme.typography.titleLarge)
                        Text("${b.name} (${b.min} د)", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        Text(if (i in done) "✅" else "▶")
                    }
                }
            }
            if (done.size == 6) Text("🎉 أحسنت! أكملت ساعة اليوم. نراك غداً.", style = MaterialTheme.typography.titleMedium)
        }
    } else {
        val b = blocks[screen]
        var sec by remember(screen) { mutableStateOf(b.min * 60) }
        LaunchedEffect(screen) { while (sec > 0) { delay(1000); sec-- } }
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row {
                TextButton(onClick = { screen = -1 }) { Text("رجوع") }
                Spacer(Modifier.weight(1f))
                Text("⏱ %02d:%02d".format(sec / 60, sec % 60), Modifier.padding(12.dp))
            }
            Text("${b.icon} ${b.name}", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))
            Box(Modifier.weight(1f)) {
                when (screen) {
                    0 -> Review(prev.words, speak)
                    1 -> Vocab(lesson.words, speak)
                    2 -> QuizView(lesson.listenQuiz, speak)
                    3 -> Column(Modifier.verticalScroll(rememberScrollState())) {
                        Text(lesson.gTitle, style = MaterialTheme.typography.titleLarge)
                        Text(lesson.gText, Modifier.padding(vertical = 8.dp))
                        QuizView(lesson.gQuiz, speak)
                    }
                    4 -> Speaking(lesson.speaking, speak, listen)
                    else -> Writing(lesson)
                }
            }
            Button(onClick = { s.complete(screen); done = s.done(); screen = -1 }, Modifier.fillMaxWidth()) { Text("أنهيت هذا القسم ✅") }
        }
    }
}

@Composable
fun Review(words: List<Word>, speak: (String) -> Unit) {
    var i by remember { mutableStateOf(0) }
    var show by remember { mutableStateOf(false) }
    val w = words[i % words.size]
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("راجع كلمات الدرس السابق", style = MaterialTheme.typography.titleMedium)
        Text(w.en, style = MaterialTheme.typography.displaySmall)
        Button(onClick = { speak(w.en) }) { Text("🔊 استمع") }
        if (show) Text("${w.ar}\n${w.ex}") else Button(onClick = { show = true }) { Text("أظهر المعنى") }
        if (show) Button(onClick = { i++; show = false }) { Text("التالية") }
    }
}

@Composable
fun Vocab(words: List<Word>, speak: (String) -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        words.forEach { w ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text("${w.en} = ${w.ar}", style = MaterialTheme.typography.titleMedium)
                        Text(w.ex)
                    }
                    TextButton(onClick = { speak(w.ex) }) { Text("🔊") }
                }
            }
        }
    }
}

@Composable
fun QuizView(items: List<Quiz>, speak: (String) -> Unit) {
    var i by remember { mutableStateOf(0) }
    var picked by remember { mutableStateOf<Int?>(null) }
    var score by remember { mutableStateOf(0) }
    if (i >= items.size) { Text("النتيجة: $score / ${items.size} 🎯", style = MaterialTheme.typography.titleLarge); return }
    val q = items[i]
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(q.q, style = MaterialTheme.typography.titleMedium)
        q.audio?.let { a -> Button(onClick = { speak(a) }) { Text("🔊 شغّل الصوت") } }
        q.options.forEachIndexed { k, o ->
            OutlinedButton(
                onClick = { if (picked == null) { picked = k; if (k == q.answer) score++ } },
                Modifier.fillMaxWidth()
            ) { Text(o + if (picked != null && k == q.answer) "  ✅" else if (picked == k) "  ❌" else "") }
        }
        if (picked != null) Button(onClick = { i++; picked = null }) { Text("التالي") }
    }
}

private fun norm(t: String) = t.lowercase().replace(Regex("[^a-z ]"), "").split(" ").filter { it.isNotBlank() }

@Composable
fun Speaking(phrases: List<String>, speak: (String) -> Unit, listen: ((String) -> Unit) -> Unit) {
    var i by remember { mutableStateOf(0) }
    var heard by remember { mutableStateOf("") }
    if (i >= phrases.size) { Text("ممتاز! أكملت التدريب 🎉", style = MaterialTheme.typography.titleLarge); return }
    val p = phrases[i]
    val target = norm(p)
    val score = if (heard.isEmpty()) 0 else { val h = norm(heard); target.count { it in h } * 100 / target.size }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("كرر الجملة بصوت واضح:")
        Text(p, style = MaterialTheme.typography.headlineSmall)
        Button(onClick = { speak(p) }) { Text("🔊 استمع أولاً") }
        Button(onClick = { listen { heard = it } }) { Text("🎤 تحدّث الآن") }
        if (heard.isNotEmpty()) {
            Text("سمعتُ: $heard")
            Text(if (score >= 80) "ممتاز $score% 🌟" else "حاول مجدداً $score%")
            Button(onClick = { i++; heard = "" }) { Text("الجملة التالية") }
        }
    }
}

@Composable
fun Writing(l: Lesson) {
    var text by remember { mutableStateOf("") }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(l.writing, style = MaterialTheme.typography.titleMedium)
        Text("حاول استخدام كلمات اليوم:")
        l.words.forEach { w -> Text((if (text.lowercase().contains(w.en)) "✅ " else "⬜ ") + w.en) }
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth().height(180.dp), placeholder = { Text("Write in English...") })
        Text("عدد الكلمات: ${text.split(" ").count { it.isNotBlank() }}")
    }
}
