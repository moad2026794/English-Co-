package com.coach.english

data class Word(val en: String, val ar: String, val ex: String)
data class Quiz(val q: String, val options: List<String>, val answer: Int, val audio: String? = null)
data class Lesson(
    val title: String, val words: List<Word>,
    val gTitle: String, val gText: String, val gQuiz: List<Quiz>,
    val listening: List<String>, val speaking: List<String>, val writing: String
) {
    val listenQuiz get() = listening.map { Quiz("ماذا سمعت؟", listening, listening.indexOf(it), it) }
}

val lessons = listOf(
    Lesson(
        "التعريف بالنفس",
        listOf(
            Word("introduce", "يُعرّف", "Let me introduce myself."),
            Word("hobby", "هواية", "My hobby is reading."),
            Word("neighbor", "جار", "My neighbor is very kind."),
            Word("schedule", "جدول", "I have a busy schedule."),
            Word("usually", "عادةً", "I usually wake up early.")
        ),
        "المضارع البسيط (Present Simple)",
        "نستخدمه للعادات والحقائق.\nI work / You work / They work\nمع He / She / It نضيف s:  She works.\nللنفي: don't / doesn't + الفعل الأصلي.",
        listOf(
            Quiz("She ___ to school every day.", listOf("go", "goes", "going"), 1),
            Quiz("I ___ coffee in the morning.", listOf("drink", "drinks", "drinking"), 0),
            Quiz("He ___ like fish.", listOf("don't", "doesn't", "isn't"), 1)
        ),
        listOf("My name is Sara and I live in Cairo.", "I usually wake up at seven.", "Nice to meet you."),
        listOf("Nice to meet you.", "I usually wake up at seven.", "My hobby is reading books."),
        "اكتب 4 جمل تعرّف فيها بنفسك."
    ),
    Lesson(
        "في المطعم",
        listOf(
            Word("menu", "قائمة الطعام", "Can I see the menu?"),
            Word("order", "يطلب", "I would like to order."),
            Word("bill", "الفاتورة", "The bill, please."),
            Word("delicious", "لذيذ", "This soup is delicious."),
            Word("recommend", "يوصي", "What do you recommend?")
        ),
        "التعبير بـ Would like",
        "للطلب بأدب نقول:  I would like a coffee, please.\nللسؤال:  Would you like some tea?\nأكثر لباقة من I want.",
        listOf(
            Quiz("I ___ like a glass of water.", listOf("would", "am", "do"), 0),
            Quiz("___ you like some tea?", listOf("Would", "Are", "Does"), 0),
            Quiz("Choose the polite sentence:", listOf("Give me water.", "I want water.", "I would like water, please."), 2)
        ),
        listOf("Can I see the menu, please?", "I would like to order a salad.", "The bill, please."),
        listOf("What do you recommend?", "This soup is delicious.", "I would like to order, please."),
        "اكتب حواراً قصيراً بينك وبين النادل."
    ),
    Lesson(
        "السفر والاتجاهات",
        listOf(
            Word("ticket", "تذكرة", "I bought a ticket."),
            Word("luggage", "أمتعة", "Where is my luggage?"),
            Word("direction", "اتجاه", "Can you give me directions?"),
            Word("straight", "مباشرة", "Go straight ahead."),
            Word("arrive", "يصل", "We arrive at noon.")
        ),
        "الماضي البسيط (Past Simple)",
        "للأحداث التي انتهت.\nالأفعال المنتظمة: + ed  (visit → visited)\nغير المنتظمة تتغير: go → went, see → saw, eat → ate.",
        listOf(
            Quiz("Yesterday I ___ to the market.", listOf("go", "went", "going"), 1),
            Quiz("She ___ the movie last night.", listOf("watch", "watched", "watching"), 1),
            Quiz("We ___ pizza last Friday.", listOf("eat", "eats", "ate"), 2)
        ),
        listOf("Where is the train station?", "Go straight and turn left.", "We arrive at noon."),
        listOf("Can you give me directions?", "Go straight ahead.", "I lost my luggage."),
        "اكتب 4 جمل عن آخر رحلة قمت بها بصيغة الماضي."
    )
)
